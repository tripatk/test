
# AP Disjoin Ansible Playbook

## How to run
```bash
cd ap_disjoin_ansible
# (optional) export credentials instead of using group_vars/all.yml
export WLC_USERNAME=netadmin
export WLC_PASSWORD='netadmin@hcl'
export AP_USERNAME=admin
export AP_PASSWORD='Passw0rd@123'
export DEVICE_USERNAME=netadmin
export DEVICE_PASSWORD='Netadmin@hcl'
export DNAC_USERNAME=netadmin1
export DNAC_PASSWORD='Netadmin@hcl'

# Ensure TextFSM templates path is visible to the filter
export NET_TEXTFSM="$(pwd)/templates"

ansible-playbook site.yml -e log_file="./logs/{{ ap_details.ap_ip }}_ap_disjoin.log"
```

## Notes
* Uses TextFSM templates located under `./templates` via the `parse_cli_textfsm` filter.
* Switch IP/interface are learned from `show ap cdp neighbors detail` first; if not found, the DNAC role discovers them via REST APIs.
* Final customer report is written to `./reports/<AP_IP>_report.txt`.
