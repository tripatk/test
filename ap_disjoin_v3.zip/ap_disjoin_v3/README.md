# AP Disjoin Self-Healing Automation (v3 – Flat Task Based)

## What Changed from v2 (Role-Based)

v2 used Ansible roles (`roles/wlc/`, `roles/switch/`, etc.).
v3 removes all roles. Everything lives as numbered `include_tasks`
files in a single `tasks/` directory. The logic is identical —
only the structure changed.

---

## Project Structure

```
ap_disjoin_v3/
├── ap_disjoin.yml              ← Single entry point (run this)
├── config/
│   └── commands.yml            ← All CLI commands in one place
├── group_vars/
│   ├── all.yml                 ← Global variables, thresholds, API URLs
│   └── ap.yml                  ← AP SSH overrides
├── inventory/
│   └── hosts.ini
├── templates/                  ← TextFSM parsing templates
│   ├── ap_history.textfsm
│   ├── ap_summary.textfsm
│   ├── cdp_ap_detail.textfsm
│   ├── join_summary.textfsm
│   ├── power_inline.textfsm
│   └── traceroute.textfsm
├── reports_templates/          ← Jinja2 report templates
│   ├── report.j2
│   └── workflow_log.j2
└── tasks/                      ← All logic here, 26 numbered files
    ├── 01_input_extraction.yml
    ├── 02_ap_discovery.yml
    ├── 03_wlc_credential_auth.yml
    ├── 04_wlc_platform_version.yml
    ├── 05_wlc_cpu_memory.yml
    ├── 06_wlc_license_capacity.yml
    ├── 07_wlc_ap_state_history.yml
    ├── 08_wlc_cdp_switch_discovery.yml
    ├── 09_network_path.yml
    ├── 10_wlc_dtls_cert_check.yml      ← DTLS path only
    ├── 11_wlc_ap_mic_ssc_check.yml     ← DTLS path only
    ├── 12_wlc_time_sync.yml            ← DTLS path only
    ├── 13_ap_time_sync.yml             ← DTLS path only
    ├── 14_sw_credential_discovery.yml
    ├── 15_sw_add_host.yml
    ├── 16_sw_interface_health.yml
    ├── 16a_sw_interface_iteration.yml  ← Called in loop by task 16
    ├── 17_sw_tdr_diagnostics.yml
    ├── 18_sw_port_decision.yml
    ├── 19_sw_port_bounce.yml           ← Unhealthy path only
    ├── 20_sw_vlan_check.yml
    ├── 21_sw_ap_reachability.yml
    ├── 22_sw_poe_power.yml
    ├── 23_report_normalise.yml
    ├── 24_report_resolution.yml
    ├── 25_report_context.yml
    └── 26_report_render.yml
```

---

## Execution Flow

```
ap_disjoin.yml
  ├── SECTION A: Input & Discovery
  │     01 → Parse ETMS/VCATS ticket
  │     02 → Inventory API + CAPWAP → controller_ip
  │     03 → Validate WLC credentials
  │
  ├── SECTION B: WLC Health
  │     04 → show version (OS, SW version, HW PID)
  │     05 → CPU and memory check
  │     06 → License and AP count
  │
  ├── SECTION C: AP State & Topology
  │     07 → AP join state, history, uptime
  │     08 → CDP → switch IP + interface
  │     09 → Ping + traceroute WLC → AP
  │
  ├── SECTION D: DTLS Path (only when reason contains 'dtls')
  │     10 → WLC DTLS trustpoint + PKI cert
  │     11 → AP MIC/SSC cert check
  │     12 → WLC clock + NTP
  │     13 → AP clock check
  │
  ├── SECTION E: Switch Checks & Remediation
  │     14 → VCATS API → switch credentials
  │     15 → Add switch to Ansible inventory
  │     16 → 5x interface health snapshots
  │     17 → TDR cable diagnostics
  │     18 → Healthy / Unhealthy decision
  │     19 → Port bounce (Unhealthy only)
  │     20 → VLAN check + correction
  │     21 → AP reachability confirmation
  │     22 → PoE check + power inline auto
  │
  └── SECTION F: Report
        23 → Normalise optional variables
        24 → Calculate resolution time
        25 → Build report_ctx dict
        26 → Write log + report files; SNOW stub
```

---

## How to Run

```bash
cd ap_disjoin_v3

export INV_FILE=/path/to/incident_payload.json
export NET_TEXTFSM="$(pwd)/templates"

# Optional: supply correct VLAN if VLAN mismatch remediation needed
# ansible-playbook ap_disjoin.yml -e correct_vlan=100

ansible-playbook ap_disjoin.yml
```

---

## Platform Migration Note (VCATS → iAutomate)

Both platforms are Jenkins-based with the same ETMS/VBSM backend APIs.
Search for `# TODO` comments in the task files for the specific items
that need confirming when switching platforms:

| Item | File |
|---|---|
| INV_FILE env var name | tasks/01_input_extraction.yml |
| Auth token field name | tasks/01_input_extraction.yml |
| requestId JSON path | tasks/01_input_extraction.yml |
| API base URL env var | group_vars/all.yml |
| credentialIds value | tasks/14_sw_credential_discovery.yml |
| SNOW API call | tasks/26_report_render.yml |
